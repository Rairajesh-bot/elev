﻿namespace ElevatorLift
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel2 = new System.Windows.Forms.Panel();
            this.emergencyBtn = new System.Windows.Forms.Button();
            this.goGroundFloor = new System.Windows.Forms.Button();
            this.goFirstFloor = new System.Windows.Forms.Button();
            this.openDoor = new System.Windows.Forms.Button();
            this.closeDoor = new System.Windows.Forms.Button();
            this.requestLiftGround = new System.Windows.Forms.Button();
            this.requestLiftFirst = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.leftDoorDown = new System.Windows.Forms.PictureBox();
            this.rightDoorDown = new System.Windows.Forms.PictureBox();
            this.leftDoorUp = new System.Windows.Forms.PictureBox();
            this.rightDoorUp = new System.Windows.Forms.PictureBox();
            this.liftBox = new System.Windows.Forms.PictureBox();
            this.floor = new System.Windows.Forms.Panel();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.timer_upper_door_close = new System.Windows.Forms.Timer(this.components);
            this.timer_upper_door_open = new System.Windows.Forms.Timer(this.components);
            this.timer_lower_door_close = new System.Windows.Forms.Timer(this.components);
            this.timer_lower_door_open = new System.Windows.Forms.Timer(this.components);
            this.timer_lift_down = new System.Windows.Forms.Timer(this.components);
            this.timer_lift_up = new System.Windows.Forms.Timer(this.components);
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.leftDoorDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rightDoorDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.leftDoorUp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rightDoorUp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.liftBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackgroundImage = global::ElevatorLift.Properties.Resources.panel;
            this.panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel2.Controls.Add(this.emergencyBtn);
            this.panel2.Controls.Add(this.goGroundFloor);
            this.panel2.Controls.Add(this.goFirstFloor);
            this.panel2.Controls.Add(this.openDoor);
            this.panel2.Controls.Add(this.closeDoor);
            this.panel2.Location = new System.Drawing.Point(131, 309);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(200, 448);
            this.panel2.TabIndex = 5;
            // 
            // emergencyBtn
            // 
            this.emergencyBtn.BackgroundImage = global::ElevatorLift.Properties.Resources.emergency;
            this.emergencyBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.emergencyBtn.Location = new System.Drawing.Point(75, 360);
            this.emergencyBtn.Name = "emergencyBtn";
            this.emergencyBtn.Size = new System.Drawing.Size(67, 65);
            this.emergencyBtn.TabIndex = 4;
            this.emergencyBtn.UseVisualStyleBackColor = true;
            // 
            // goGroundFloor
            // 
            this.goGroundFloor.BackgroundImage = global::ElevatorLift.Properties.Resources.groundfloorbutton;
            this.goGroundFloor.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.goGroundFloor.Location = new System.Drawing.Point(117, 288);
            this.goGroundFloor.Name = "goGroundFloor";
            this.goGroundFloor.Size = new System.Drawing.Size(67, 65);
            this.goGroundFloor.TabIndex = 3;
            this.goGroundFloor.UseVisualStyleBackColor = true;
            this.goGroundFloor.Click += new System.EventHandler(this.goGroundFloor_Click_1);
            // 
            // goFirstFloor
            // 
            this.goFirstFloor.BackgroundImage = global::ElevatorLift.Properties.Resources.Firstfloorbutton;
            this.goFirstFloor.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.goFirstFloor.Location = new System.Drawing.Point(14, 288);
            this.goFirstFloor.Name = "goFirstFloor";
            this.goFirstFloor.Size = new System.Drawing.Size(67, 65);
            this.goFirstFloor.TabIndex = 2;
            this.goFirstFloor.UseVisualStyleBackColor = true;
            this.goFirstFloor.Click += new System.EventHandler(this.goFirstFloor_Click_1);
            // 
            // openDoor
            // 
            this.openDoor.BackgroundImage = global::ElevatorLift.Properties.Resources.door_open;
            this.openDoor.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.openDoor.Location = new System.Drawing.Point(115, 151);
            this.openDoor.Name = "openDoor";
            this.openDoor.Size = new System.Drawing.Size(67, 65);
            this.openDoor.TabIndex = 1;
            this.openDoor.UseVisualStyleBackColor = true;
            this.openDoor.Click += new System.EventHandler(this.openDoor_Click);
            // 
            // closeDoor
            // 
            this.closeDoor.BackgroundImage = global::ElevatorLift.Properties.Resources.door_close;
            this.closeDoor.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.closeDoor.Location = new System.Drawing.Point(14, 151);
            this.closeDoor.Name = "closeDoor";
            this.closeDoor.Size = new System.Drawing.Size(67, 65);
            this.closeDoor.TabIndex = 0;
            this.closeDoor.UseVisualStyleBackColor = true;
            // 
            // requestLiftGround
            // 
            this.requestLiftGround.BackgroundImage = global::ElevatorLift.Properties.Resources.requestup_button;
            this.requestLiftGround.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.requestLiftGround.Location = new System.Drawing.Point(800, 785);
            this.requestLiftGround.Name = "requestLiftGround";
            this.requestLiftGround.Size = new System.Drawing.Size(67, 65);
            this.requestLiftGround.TabIndex = 4;
            this.requestLiftGround.UseVisualStyleBackColor = true;
            // 
            // requestLiftFirst
            // 
            this.requestLiftFirst.BackgroundImage = global::ElevatorLift.Properties.Resources.requestdown_button;
            this.requestLiftFirst.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.requestLiftFirst.Location = new System.Drawing.Point(788, 248);
            this.requestLiftFirst.Name = "requestLiftFirst";
            this.requestLiftFirst.Size = new System.Drawing.Size(67, 65);
            this.requestLiftFirst.TabIndex = 3;
            this.requestLiftFirst.UseVisualStyleBackColor = true;
            this.requestLiftFirst.Click += new System.EventHandler(this.requestLiftFirst_Click);
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = global::ElevatorLift.Properties.Resources.Panelko_laagi;
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.Controls.Add(this.leftDoorDown);
            this.panel1.Controls.Add(this.rightDoorDown);
            this.panel1.Controls.Add(this.leftDoorUp);
            this.panel1.Controls.Add(this.rightDoorUp);
            this.panel1.Controls.Add(this.liftBox);
            this.panel1.Controls.Add(this.floor);
            this.panel1.Controls.Add(this.pictureBox4);
            this.panel1.Controls.Add(this.pictureBox3);
            this.panel1.Location = new System.Drawing.Point(420, 74);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(356, 933);
            this.panel1.TabIndex = 2;
            // 
            // leftDoorDown
            // 
            this.leftDoorDown.Image = global::ElevatorLift.Properties.Resources.left_door;
            this.leftDoorDown.Location = new System.Drawing.Point(176, 585);
            this.leftDoorDown.Name = "leftDoorDown";
            this.leftDoorDown.Size = new System.Drawing.Size(157, 345);
            this.leftDoorDown.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.leftDoorDown.TabIndex = 7;
            this.leftDoorDown.TabStop = false;
            // 
            // rightDoorDown
            // 
            this.rightDoorDown.Image = global::ElevatorLift.Properties.Resources.right_door;
            this.rightDoorDown.Location = new System.Drawing.Point(19, 585);
            this.rightDoorDown.Name = "rightDoorDown";
            this.rightDoorDown.Size = new System.Drawing.Size(157, 345);
            this.rightDoorDown.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.rightDoorDown.TabIndex = 6;
            this.rightDoorDown.TabStop = false;
            // 
            // leftDoorUp
            // 
            this.leftDoorUp.Image = global::ElevatorLift.Properties.Resources.left_door;
            this.leftDoorUp.Location = new System.Drawing.Point(176, 41);
            this.leftDoorUp.Name = "leftDoorUp";
            this.leftDoorUp.Size = new System.Drawing.Size(157, 345);
            this.leftDoorUp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.leftDoorUp.TabIndex = 5;
            this.leftDoorUp.TabStop = false;
            // 
            // rightDoorUp
            // 
            this.rightDoorUp.Image = global::ElevatorLift.Properties.Resources.right_door;
            this.rightDoorUp.Location = new System.Drawing.Point(19, 41);
            this.rightDoorUp.Name = "rightDoorUp";
            this.rightDoorUp.Size = new System.Drawing.Size(157, 345);
            this.rightDoorUp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.rightDoorUp.TabIndex = 4;
            this.rightDoorUp.TabStop = false;
            // 
            // liftBox
            // 
            this.liftBox.Image = global::ElevatorLift.Properties.Resources.liftbox;
            this.liftBox.Location = new System.Drawing.Point(22, 585);
            this.liftBox.Name = "liftBox";
            this.liftBox.Size = new System.Drawing.Size(311, 345);
            this.liftBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.liftBox.TabIndex = 3;
            this.liftBox.TabStop = false;
            // 
            // floor
            // 
            this.floor.BackgroundImage = global::ElevatorLift.Properties.Resources.floor1;
            this.floor.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.floor.Location = new System.Drawing.Point(0, 386);
            this.floor.Name = "floor";
            this.floor.Size = new System.Drawing.Size(356, 161);
            this.floor.TabIndex = 2;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::ElevatorLift.Properties.Resources.Lift_frame;
            this.pictureBox4.Location = new System.Drawing.Point(0, 544);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(356, 386);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 1;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::ElevatorLift.Properties.Resources.Lift_frame;
            this.pictureBox3.Location = new System.Drawing.Point(0, 0);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(356, 386);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 0;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = global::ElevatorLift.Properties.Resources.emergency;
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox2.Image = global::ElevatorLift.Properties.Resources.wall;
            this.pictureBox2.Location = new System.Drawing.Point(5, 549);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(1300, 550);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::ElevatorLift.Properties.Resources.wall;
            this.pictureBox1.Location = new System.Drawing.Point(5, -1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1300, 550);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // timer_upper_door_close
            // 
            this.timer_upper_door_close.Interval = 10;
            this.timer_upper_door_close.Tick += new System.EventHandler(this.timer_upper_door_close_Tick);
            // 
            // timer_upper_door_open
            // 
            this.timer_upper_door_open.Tick += new System.EventHandler(this.timer_upper_door_open_Tick);
            // 
            // timer_lower_door_close
            // 
            this.timer_lower_door_close.Tick += new System.EventHandler(this.timer_lower_door_close_Tick);
            // 
            // timer_lower_door_open
            // 
            this.timer_lower_door_open.Tick += new System.EventHandler(this.timer_lower_door_open_Tick);
            // 
            // timer_lift_down
            // 
            this.timer_lift_down.Tick += new System.EventHandler(this.timer_lift_down_Tick);
            // 
            // timer_lift_up
            // 
            this.timer_lift_up.Tick += new System.EventHandler(this.timer_lift_up_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ClientSize = new System.Drawing.Size(1550, 1116);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.requestLiftGround);
            this.Controls.Add(this.requestLiftFirst);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.leftDoorDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rightDoorDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.leftDoorUp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rightDoorUp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.liftBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Panel floor;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox liftBox;
        private System.Windows.Forms.PictureBox rightDoorUp;
        private System.Windows.Forms.PictureBox leftDoorUp;
        private System.Windows.Forms.PictureBox leftDoorDown;
        private System.Windows.Forms.PictureBox rightDoorDown;
        private System.Windows.Forms.Button requestLiftFirst;
        private System.Windows.Forms.Button requestLiftGround;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button closeDoor;
        private System.Windows.Forms.Button openDoor;
        private System.Windows.Forms.Button goFirstFloor;
        private System.Windows.Forms.Button goGroundFloor;
        private System.Windows.Forms.Button emergencyBtn;
        private System.Windows.Forms.Timer timer_upper_door_close;
        private System.Windows.Forms.Timer timer_upper_door_open;
        private System.Windows.Forms.Timer timer_lower_door_close;
        private System.Windows.Forms.Timer timer_lower_door_open;
        private System.Windows.Forms.Timer timer_lift_down;
        private System.Windows.Forms.Timer timer_lift_up;
    }
}

