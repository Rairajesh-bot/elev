﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ElevatorLift
{
    public partial class Form1 : Form
    {

        int x_leftdoorclose = 176;
        int x_leftdooropen = 331;
        int x_rightdoorclose = 19;
        int x_rightdooropen = -132;
        int y_liftBoxDown = 585;
        int y_liftBoxUp = 41;

        bool arrived_first_floor = false;
        bool arrived_ground_floor = false;

        bool go_up = false;
        bool go_down = false;



        public Form1()
        {
            InitializeComponent();
        }

        private void timer_upper_door_close_Tick(object sender, EventArgs e)
        {
            if (rightDoorUp.Left <= x_rightdoorclose && leftDoorUp.Left >= x_leftdoorclose)

            {
                rightDoorUp.Left += 1;
                leftDoorUp.Left -= 1;
            }
            else
            {
                timer_upper_door_close.Enabled = false;

                if(go_down==true)
                {
                    timer_lift_down.Enabled = true;
                    go_down = false;
                }
            }
        }

        private void timer_upper_door_open_Tick(object sender, EventArgs e)
        {
            if (rightDoorUp.Left >= x_rightdooropen && leftDoorUp.Left <= x_leftdooropen)
            {
                rightDoorUp.Left -= 1;
                leftDoorUp.Left += 1;
            }
            else
            {
                timer_upper_door_open.Enabled = false;

            }
        }
        private void doorOpenUp()
        {
            timer_upper_door_open.Enabled = true;
            timer_upper_door_close.Enabled = false;
        }
           
        private void doorOpenDown()
        {
            timer_lower_door_open.Enabled = true;
            timer_lower_door_close.Enabled = false;
        }
        private void openDoor_Click(object sender, EventArgs e)
        {
            if (arrived_first_floor == true)
            {
                doorOpenUp();
            }
            else if (arrived_ground_floor == true)
            {
                doorOpenDown();
            } 
        }
        private void doorCloseUp()
        {
            timer_upper_door_close.Enabled = true;
            timer_lower_door_open.Enabled = false;
        }
        private void doorCloseDown()
        {
            timer_lower_door_open.Enabled = true;
            timer_lower_door_close.Enabled = false;
        }

        private void closeDoor_Click(object sender, EventArgs e)
        {
            if (arrived_first_floor == true)
            {
                doorCloseUp();
            }
            else if (arrived_ground_floor == true)
            {
               doorCloseDown();
            }
        }
        private void timer_lower_door_close_Tick(object sender, EventArgs e)
        {
            if (rightDoorDown.Left <= x_rightdoorclose && leftDoorDown.Left >= x_leftdoorclose)

            {
                rightDoorDown.Left += 1;
                leftDoorDown.Left -= 1;
            }
            else
            {
                timer_lower_door_close.Enabled = false;

                if(go_up==true)
                {
                    timer_lift_up.Enabled = true;
                    go_up = false;
                }
            }
        }

        private void timer_lower_door_open_Tick(object sender, EventArgs e)
        {
            if (rightDoorDown.Left >= x_rightdooropen && leftDoorDown.Left <= x_leftdooropen)

            {
                rightDoorDown.Left -= 1;
                leftDoorDown.Left += 1;
            }
            else
            {
                timer_lower_door_open.Enabled = false;
            }
        }
         private void timer_lift_down_Tick(object sender, EventArgs e)
        {
            if (liftBox.Top <= y_liftBoxDown)
            {
                liftBox.Top -= 1;
            }
            else
            {
                timer_lift_down.Enabled = false;
               // requestLiftFirst.Enabled = true;
                goFirstFloor.Enabled = true;
                closeDoor.Enabled = true;
                openDoor.Enabled = true;
                //requestLiftFirst.BackColor = Color.White;
                //requestLiftGround.BackColor = Color.White;


                
                arrived_ground_floor = true;
                doorOpenDown();
            }
        }

        private void timer_lift_up_Tick(object sender, EventArgs e)
        {
            if (liftBox.Top >= y_liftBoxUp)
            {
                liftBox.Top -= 1;
            }
            else
            {
                timer_lift_up.Enabled = false;
                //requestLiftGround.Enabled = true;
                goGroundFloor.Enabled = true;
                closeDoor.Enabled = true;
                openDoor.Enabled = true;
                //requestLiftGround.BackColor = Color.White;
                //requestLiftFirst.BackColor = Color.White;


                
                arrived_first_floor = true;
                doorOpenUp();
            }

        }
        private void moveTogroundFloor()
        {
            go_down = true;
            doorCloseUp();

            //goFirstFloor.Enabled = false;
            //requestLiftFirst.Enabled = false;
            closeDoor.Enabled = false;
            closeDoor.Enabled = false;
            arrived_first_floor = false;
            //insertdata("Lift Going Down");


        }
        private void moveToFirstFloor()
        {
            go_up = true;
            doorCloseDown();
            //goGroundFloor.Enabled = false;
            //requestLiftGround.Enabled = false;
            closeDoor.Enabled = false;
            openDoor.Enabled = false;
            arrived_ground_floor = false;
            //insertdata("Lift Going Up");

        }
        

        private void requestLiftFirst_Click(object sender, EventArgs e)
        {
            moveToFirstFloor();
        }
        private void goFirstFloor_Click_1(object sender, EventArgs e)
        {
            moveToFirstFloor();
        }

        private void goGroundFloor_Click_1(object sender, EventArgs e)
        {
            moveTogroundFloor();
        }
    }
}
    
